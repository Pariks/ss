<?php $__env->startSection('content'); ?>

<div class="jumbotron" style="background-image: url('/images/slideshow/3.jpg'); width: 100%; height: 300px;">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading" style="align-content: center; text-align: center;">
                    <h2 >Welcome! <?php echo e($user->name); ?></h2>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4">
                            <h4>Let's begin Gifting</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <p>Get <span class="label label-success">130$</span> worth of gifts on <span class="label label-default">100$</span> you spend.
                    <a class="btn btn-link" href="<?php echo e(url('/deal')); ?>">
                        <i class="fa fa-plus-circle"></i>
                        More Deals
                    </a>
                </p>
            </div>
        </div>
        <?php if(isset($data) && array_key_exists('captcha', $data)): ?>
            <?php if($data['captcha'] === false): ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2  alert alert-danger" style="text-align: center;">
                            <strong >Error: Please Enter Captcha!</strong>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(isset($data) && array_key_exists('sender', $data) && array_key_exists('receiver', $data) && array_key_exists('order', $data)): ?>
            <?php if($data['sender'] === true && $data['receiver'] === false && $data['order'] === false): ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2  alert alert-success" style="text-align: center;">
                            <strong >order placed!</strong>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/makePayment')); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Fill out details and send gift</h4>
                        </div>
                        <div class="card-block">
                            <div class="panel panel-default">
                                <div class="panel-heading">Sender's Detail - Billing Address</div>
                                <div class="panel-body">

                                   <?php echo $__env->make('address.sender', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="card">
                        <div class="card-header">

                        </div>
                        <div class="card-block">
                            <div class="panel panel-default">
                                <div class="panel-heading">Receiver's Detail - Gifting Address</div>
                                <div class="panel-body">
                                    <?php echo $__env->make('address.receiver', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>