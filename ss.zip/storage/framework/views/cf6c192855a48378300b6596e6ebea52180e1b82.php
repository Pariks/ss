<?php $__env->startSection('content'); ?>
    <link href="/css/custome/deals.css" rel="stylesheet">
    <div class="jumbotron center-block" style="background-image: url('/images/deals/dealCover.jpg'); width: 100%;  height: 300px;">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-heading" style="   ">
                       <img src="/images/deals/deal.png" class="card-img" style="float: left; top: 0px; " height="100" ><h2>Exclusive Deals and Offers Get gift worth up to <span class="label label-success" >5x</span></h2>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6 col-md-offset-2">
                                <h4>Happiness at your single click</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row center-block" id="deal<?php echo e($deal['amount']); ?>">
            <div id="deal<?php echo e($deal['amount']); ?>-hearder">
                <p class="lead" >Get <span class="label label-success">130$</span> worth of gifts on <span class="label label-default"><?php echo e($deal['amount']); ?>$</span> you spend.
            </div>
            <div id="deal<?php echo e($deal['amount']); ?>-body" >
                <span class="btn btn-default btn-white pull-right" data-toggle="tooltip" data-placement="top"  id="clickToCopy<?php echo e($deal['amount']); ?>"  title="Click to Copy!">DEAL<?php echo e($deal['amount']); ?></span>
                <span class="blink-link pull-right">Copy your <span class="label label-warning">Deal</span> code NOW!<i class="fa fa-arrow-right"></i> </span>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <script src="/js/custome/deals.js"></script>
    <script src="/js/notification/notify.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>