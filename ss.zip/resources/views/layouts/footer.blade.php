
        <div class="container-fluid" style="
    height:50px;
    bottom:0px;
    margin-top: 50px;
      ">
            <div class="row">
                <div class="col-md-12 col-md-offset-4">
                    <p class="text-muted credit"> &copy; Copyright by SecretSanta INC. </p>
                </div>
            </div>
       </div>

