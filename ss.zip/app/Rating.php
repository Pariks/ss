<?php


namespace App;

use Illuminate\Database\Eloquent\Model;
use willvincent\Rateable\Rateable;

class Rating extends Model
{
    use Rateable;
}