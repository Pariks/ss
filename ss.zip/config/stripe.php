<?php

return [

    'secret_key' => 'sk_test_wpuUwgrRSFzETx9XVAri5gDf',
    'publishable_key' => 'pk_test_BMBjjYyXPoPoHwNM44pv2Atf'

];