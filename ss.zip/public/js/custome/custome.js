$(document).ready(function(){

    var selector = '.nav li';
    $(selector).on('click', function(){

        $(this).css('color', 'red');
    });

   
});